#===============================================================================
# Name   : R script template
# Author : Tinn-R Team
# Date   : 31/01/2014 19:48:33
# Version: v3
# Aim    : Template to R script
# URL    : http://nbcgib.uesc.br/lec/software/editores/tinn-r/en
#===============================================================================

#===============================
# example: 01
#===============================
set.seed(2013)

dad <- rnorm(x=1e3,
             mean=10,
             sd=2)


