This folder stores (by default):The XML files 'Cache.xmk', 'Comments.xml', 'Completion.xml', 'Rcard.xlm',  'Rmirrors.xml' and 'Shortcuts.xml'.
