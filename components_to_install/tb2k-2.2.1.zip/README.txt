===========================================================================
 Toolbar2000 README
===========================================================================

Thank you for downloading Toolbar2000.

For details on installing and using Toolbar2000, please refer to the
Toolbar2000 help file - tb2k.chm. To open it, double-click it in Windows
Explorer.

This file is in HTML Help format. If you are using an older version of
Windows that does not come with HTML Help, it can be downloaded at:

  http://msdn.microsoft.com/library/en-us/htmlhelp/html/hwMicrosoftHTMLHelpDownloads.asp

You will also need Internet Explorer 4.0 or later (5.0 is preferred),
downloadable from:

  http://www.microsoft.com/ie/


- Jordan Russell  (www.jrsoftware.org)
