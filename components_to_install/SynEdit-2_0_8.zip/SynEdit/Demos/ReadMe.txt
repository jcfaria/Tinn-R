SynEdit demo apps
-----------------

There a some demo apps to show how to use different components of the SynEdit
component suite.  Each folder has a ReadMe.txt file where the minimum version of
Delphi needed to compile the project can be found.  Sorry, there are no BCB
projects, but it should be possible to create new projects with BCB, remove the
automatically created main form, and add the form from the sample folder.