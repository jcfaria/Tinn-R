SimpleIDEDemo.dpr
-----------------

- Needs Delphi 4 or higher.
- Demonstrates how to highlight breakpoint or current lines in different colors
  (as seen in the Delphi IDE).  Shows how to draw into the gutter without using
  marker objects, using a SynEdit plugin.

