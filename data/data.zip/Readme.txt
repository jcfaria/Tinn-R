This folder stores (by default):The XML files: Cache.xml, Comments.xml, Completion.xml, Rcard.xlm, Rmirrors.xml, Shortcuts.xml, RH_Send.xml, RH_Control.xml and RH_Custom.xml.
