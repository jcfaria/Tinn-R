# formatR

[![Build Status](https://travis-ci.org/yihui/formatR.svg)](https://travis-ci.org/yihui/formatR)
[![Downloads from the RStudio CRAN mirror](https://cranlogs.r-pkg.org/badges/formatR)](https://cran.r-project.org/package=formatR)

Format R code automatically.

See the package homepage <https://yihui.name/formatR> for more information.
