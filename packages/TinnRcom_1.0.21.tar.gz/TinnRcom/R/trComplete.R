#=======================================================================
# Orinal author: Philippe Grosjean
# Original code: [svMisc] Complete and guiComplete function
# Adapted by   : Jos� Cl�udio Faria
# Objective    : To supply the current necessity of the Tinn-R project
# Date         : 2016/05/24 - 21:18:07
#=======================================================================

trComplete <- function (code,
                        pattern='',
                        sep = '\t')
{
  # Get the environment of the object
  get.env <- function(object)
  {
    res <- getAnywhere(object)

    tmp <- ifelse(grepl('.GlobalEnv',
                        res$where), 'y', 'n')
    if (any(tmp == 'y'))
      res <- '.GlobalEnv'
    else {
      res <- grep('package:',
                  res$where,
                  value=TRUE)

      res <- gsub('package:',
                  '',
                  res)
    }

    return(res)
  }

  # Get object
  get.object <- function(string)
  {
    pos <- regexpr('[a-zA-Z0-9_\\.]+$',
                   string)

    object <- substring(string,
                        pos)

    return(object)
  }

  # by J.C.Faria http://rubular.com/r/JhFNYBnfHb
  # Check if the user sent an environment with the object, for example 'datasets::iris'
  pos <- regexpr('[a-zA-Z0-9.]+(?=::)',
                 code,
                 perl=T)

  # Try to get the environment
  env <- substring(code,
                   pos,
                   attr(pos,
                        'match.length'))

  object <- get.object(code)

  # If env is empty will getAnywhere(object)
  if (env == '')
    env <- get.env(object)

  res <- .DollarNames(eval(parse(text=code)),
                      pattern=pattern)

  res <- paste(paste(paste(res,
                           sep,
                           sep=''),
                     collapse=''),
               '[',
               env,
               ']',
               '<',
               object,
               '>',
               sep='')

  return(res)
}
