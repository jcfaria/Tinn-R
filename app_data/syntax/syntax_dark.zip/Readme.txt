This folder stores:All syntax user preferences.
